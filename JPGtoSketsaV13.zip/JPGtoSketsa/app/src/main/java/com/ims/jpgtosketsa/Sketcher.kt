package com.ims.jpgtosketsa

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.*

class SketchParams(
    val mode: Int,    // 0 pensil hitam-putih, 1 pensil berwarna, 2 komik
    val blur: Int,    // 0..100 ketebalan/kehalusan garis
    val dark: Int,    // 0..100 kegelapan / kekuatan garis
    val color: Int,   // 0..100 kekuatan warna (mode 1)
    val grain: Int,   // 0..100 tekstur kertas
    val paper: Int    // 0 putih, 1 krem, 2 papan tulis, 3 transparan (PNG, hanya garis)
)

object Sketcher {
    fun render(src: Bitmap, p: SketchParams): Bitmap {
        val w = src.width
        val h = src.height
        val n = w * h
        val px = IntArray(n)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val scale = max(w, h) / 900f
        val gray = IntArray(n) {
            val c = px[it]
            (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000
        }
        val v: IntArray = if (p.mode == 2) comic(gray, w, h, scale, p) else pencil(gray, w, h, scale, p)

        val out = IntArray(n)
        val colored = p.mode == 1
        val kc = p.color / 100f
        val pr: Float
        val pg: Float
        val pb: Float
        when (p.paper) {
            1 -> { pr = 245f; pg = 236f; pb = 215f }
            else -> { pr = 255f; pg = 255f; pb = 255f }
        }
        for (i in 0 until n) {
            val vv = v[i].toFloat()
            var lr = 255f
            var lg = 255f
            var lb = 255f
            if (colored) {
                val c = px[i]
                lr = 255f * (1f - kc) + Color.red(c) * kc
                lg = 255f * (1f - kc) + Color.green(c) * kc
                lb = 255f * (1f - kc) + Color.blue(c) * kc
            }
            if (p.paper == 3) {
                val al = (255f - vv).toInt().coerceIn(0, 255)
                out[i] = if (colored) Color.argb(al, (lr * 0.5f).toInt().coerceIn(0, 255), (lg * 0.5f).toInt().coerceIn(0, 255), (lb * 0.5f).toInt().coerceIn(0, 255))
                else Color.argb(al, 20, 20, 24)
                continue
            }
            val r: Float
            val g: Float
            val b: Float
            if (p.paper == 2) {
                val t = (255f - vv) / 255f
                r = 43f + (lr - 43f) * t
                g = 58f + (lg - 58f) * t
                b = 51f + (lb - 51f) * t
            } else {
                r = vv * lr / 255f * pr / 255f
                g = vv * lg / 255f * pg / 255f
                b = vv * lb / 255f * pb / 255f
            }
            out[i] = Color.rgb(r.toInt().coerceIn(0, 255), g.toInt().coerceIn(0, 255), b.toInt().coerceIn(0, 255))
        }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPixels(out, 0, w, 0, 0, w, h)
        return bmp
    }

    // ---------- Fungsi bantu: noise ----------
    private fun sstep(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    private fun hn(ix: Int, iy: Int, seed: Int): Float {
        var h = ix * 374761393 + iy * 668265263 + seed * 1442695041
        h = (h xor (h ushr 13)) * 1274126177
        h = h xor (h ushr 16)
        return (h and 0xFFFF) / 65535f
    }

    private fun vn(x: Float, y: Float, seed: Int): Float {
        val x0 = floor(x)
        val y0 = floor(y)
        var fx = x - x0
        var fy = y - y0
        fx = fx * fx * (3f - 2f * fx)
        fy = fy * fy * (3f - 2f * fy)
        val ix = x0.toInt()
        val iy = y0.toInt()
        val a = hn(ix, iy, seed)
        val b = hn(ix + 1, iy, seed)
        val c = hn(ix, iy + 1, seed)
        val d = hn(ix + 1, iy + 1, seed)
        return (a * (1f - fx) + b * fx) * (1f - fy) + (c * (1f - fx) + d * fx) * fy
    }

    // ---------- Gaya pensil: kontur + arsiran goresan halus + tekstur grafit ----------
    private fun pencil(gray: IntArray, w: Int, h: Int, scale: Float, p: SketchParams): IntArray {
        val n = w * h
        val vl = FloatArray(n)  // 1 = putih, 0 = garis kuat
        val inv = IntArray(n) { 1020 - gray[it] * 4 }
        boxBlur(inv, w, h, max(1, ((1.5f + p.blur * 0.12f) * scale).roundToInt()))
        val gamma = 0.75 + p.dark / 100.0 * 0.9
        val lut = FloatArray(256) { (it / 255.0).pow(gamma).toFloat() }
        for (i in 0 until n) {
            val d = max(1, 1020 - inv[i])
            val ratio = min(1f, gray[i] * 4f / d)
            vl[i] = lut[(ratio * 255f).toInt().coerceIn(0, 255)]
        }

        // Nada (tone) yang diarsir
        val gb = IntArray(n) { gray[it] * 4 }
        boxBlur(gb, w, h, max(1, (2.5f * scale).roundToInt()))
        val dExp = 1.25f - p.dark / 100f * 0.5f
        val dLut = FloatArray(1021) { (((it / 1020f) - 0.10f) / 0.78f).coerceIn(0f, 1f).pow(dExp) }

        val angs = floatArrayOf(58f, 122f, 12f, 92f)
        val thrs = floatArrayOf(0.06f, 0.30f, 0.56f, 0.78f)
        val sts = floatArrayOf(1f, 0.9f, 0.8f, 0.8f)
        val cs = FloatArray(4) { cos(Math.toRadians(angs[it].toDouble())).toFloat() }
        val sn = FloatArray(4) { sin(Math.toRadians(angs[it].toDouble())).toFloat() }
        val cb = cos(Math.toRadians(58.0)).toFloat()
        val sb = sin(Math.toRadians(58.0)).toFloat()
        val sp = 2.7f * scale
        val opac = 0.62f
        val gr = p.grain / 100f
        val sw1 = 1f / (55f * scale)
        val sw2 = 1f / (14f * scale)
        val se = 1f / (130f * scale)
        val st = 1f / (1.6f * scale)
        val hvA = FloatArray(n)
        for (y in 0 until h) {
            val yf = y.toFloat()
            for (x in 0 until w) {
                val i = y * w + x
                val xf = x.toFloat()
                val d = dLut[(1020 - gb[i]).coerceIn(0, 1020)]
                val warp = (vn(xf * sw1, yf * sw1, 7) - 0.5f) * 2.6f + (vn(xf * sw2, yf * sw2, 8) - 0.5f) * 0.7f
                var hv = 1f - 0.36f * d
                for (k in 0 until 4) {
                    if (d <= thrs[k]) continue
                    val u = xf * cs[k] + yf * sn[k]
                    val vv = -xf * sn[k] + yf * cs[k]
                    val pp = u / sp + warp + k * 0.37f
                    val fl = floor(pp)
                    val dist = abs(pp - fl - 0.5f) * 2f
                    val wk = 0.30f + 0.65f * d
                    if (dist >= wk) continue
                    val prof = 0.5f + 0.5f * cos(Math.PI.toFloat() * dist / wk)
                    val strength = 0.5f + 0.5f * hn(fl.toInt(), 0, 20 + k)
                    val seg = sstep(0.18f - 0.17f * d, 0.45f - 0.30f * d, vn(vv / (22f * scale), fl * 3.1f, 30 + k))
                    val cover = sstep(thrs[k], thrs[k] + 0.28f, d)
                    hv *= 1f - opac * prof * strength * seg * cover * sts[k]
                }
                // goresan tipis di latar kosong
                val env = sstep(0.45f, 0.8f, vn(xf * se, yf * se, 41))
                if (env > 0f) {
                    val u = xf * cb + yf * sb
                    val vv = -xf * sb + yf * cb
                    val pp = u / (sp * 1.35f) + warp
                    val fl = floor(pp)
                    val prof = (1f - abs(pp - fl - 0.5f) * 2f / 0.30f).coerceIn(0f, 1f)
                    if (prof > 0f) {
                        val seg = sstep(0.35f, 0.6f, vn(vv / (30f * scale), fl * 2.3f, 42))
                        hv *= 1f - prof * seg * env * (0.5f + 0.5f * hn(fl.toInt(), 0, 43)) * 0.07f
                    }
                }
                hvA[i] = hv
            }
        }
        // haluskan arsiran (hilangkan efek moire / pixelated), kontur tetap tajam
        val tmp = FloatArray(n)
        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w + x
            tmp[i] = (hvA[if (x > 0) i - 1 else i] + 2f * hvA[i] + hvA[if (x < w - 1) i + 1 else i]) * 0.25f
        }
        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w + x
            hvA[i] = (tmp[if (y > 0) i - w else i] + 2f * tmp[i] + tmp[if (y < h - 1) i + w else i]) * 0.25f
        }
        val out = IntArray(n)
        for (y in 0 until h) {
            val yf = y.toFloat()
            for (x in 0 until w) {
                val i = y * w + x
                val xf = x.toFloat()
                val tooth = 1f - gr * 0.12f * (0.35f * hn(x, y, 5) + 0.65f * vn(xf * st, yf * st, 6))
                out[i] = (vl[i] * hvA[i] * tooth * 255f).toInt().coerceIn(0, 255)
            }
        }
        return out
    }

    // ---------- Gaya komik: bentuk besar yang bersih, kontur tinta tipis, nada abu rata ----------
    private fun bil(a: FloatArray, sw: Int, sh: Int, fx: Float, fy: Float): Float {
        val x = fx.coerceIn(0f, sw - 1.001f)
        val y = fy.coerceIn(0f, sh - 1.001f)
        val x0 = x.toInt()
        val y0 = y.toInt()
        val tx = x - x0
        val ty = y - y0
        val i = y0 * sw + x0
        return (a[i] * (1f - tx) + a[i + 1] * tx) * (1f - ty) + (a[i + sw] * (1f - tx) + a[i + sw + 1] * tx) * ty
    }

    private fun comic(gray: IntArray, w: Int, h: Int, scale: Float, p: SketchParams): IntArray {
        val d = p.dark / 100f
        val mx = max(w, h)
        val ws = max(8, (w * 640f / mx).roundToInt())
        val hs = max(8, (h * 640f / mx).roundToInt())
        val m = ws * hs
        // 1) kecilkan ke ukuran kerja (hasil sama untuk pratinjau & hasil akhir)
        val pre = IntArray(w * h) { gray[it] * 4 }
        val f = mx / 640f
        if (f >= 1.6f) boxBlur(pre, w, h, max(1, (f * 0.5f).roundToInt()))
        val preF = FloatArray(w * h) { pre[it] / 1020f }
        var s0 = FloatArray(m)
        for (y in 0 until hs) for (x in 0 until ws) {
            s0[y * ws + x] = bil(preF, w, h, (x + 0.5f) * w / ws - 0.5f, (y + 0.5f) * h / hs - 0.5f)
        }
        // 2) haluskan tekstur, pertahankan tepi (bilateral berulang) -> area datar seperti gambar komik
        val rad = 3
        val sg = FloatArray((2 * rad + 1) * (2 * rad + 1))
        for (ky in -rad..rad) for (kx in -rad..rad) sg[(ky + rad) * (2 * rad + 1) + kx + rad] = exp(-(kx * kx + ky * ky) / 8f)
        val rl = FloatArray(256) { val t = it / 255f / 0.09f; exp(-t * t * 0.5f) }
        var sLight = s0
        repeat(4) { iter ->
            val nx = FloatArray(m)
            for (y in 0 until hs) for (x in 0 until ws) {
                val c = s0[y * ws + x]
                var sum = 0f
                var wsum = 0f
                for (ky in -rad..rad) {
                    val yy = (y + ky).coerceIn(0, hs - 1)
                    for (kx in -rad..rad) {
                        val v = s0[yy * ws + (x + kx).coerceIn(0, ws - 1)]
                        val wgt = sg[(ky + rad) * (2 * rad + 1) + kx + rad] * rl[min(255, (abs(v - c) * 255f).toInt())]
                        sum += v * wgt
                        wsum += wgt
                    }
                }
                nx[y * ws + x] = sum / wsum
            }
            s0 = nx
            if (iter == 1) sLight = nx
        }
        // kontras otomatis: regangkan 2%..98% agar foto pucat/terlalu terang tetap punya putih, abu, dan hitam
        val hist = IntArray(256)
        for (i in 0 until m) hist[(s0[i] * 255f).toInt().coerceIn(0, 255)]++
        var acc = 0
        var lo = 0
        var hi = 255
        for (k in 0..255) { acc += hist[k]; if (acc >= m * 0.02f) { lo = k; break } }
        acc = 0
        for (k in 255 downTo 0) { acc += hist[k]; if (acc >= m * 0.02f) { hi = k; break } }
        val lof = lo / 255f
        val span = max(0.25f, (hi - lo) / 255f)
        for (i in 0 until m) s0[i] = ((s0[i] - lof) / span).coerceIn(0f, 1f)
        // 3) nada abu bertingkat (hitam hanya untuk area yang benar-benar gelap)
        val lv = floatArrayOf(0.10f, 0.45f, 0.76f, 1.0f)
        val th = floatArrayOf(0.10f + 0.06f * d, 0.33f + 0.08f * d, 0.58f + 0.08f * d)
        val wd = 0.03f
        val tone = IntArray(m)
        for (i in 0 until m) {
            var t = lv[0]
            for (k in 0 until 3) t += (lv[k + 1] - lv[k]) * sstep(th[k] - wd, th[k] + wd, s0[i])
            tone[i] = (t * 1000f).toInt()
        }
        boxBlur(tone, ws, hs, 1)
        val toneF = FloatArray(m) { tone[it] / 1000f }
        // 4) kontur tinta dari gambar yang sudah dihaluskan
        val inkF = FloatArray(m)
        val s1000 = IntArray(m) { (sLight[it] * 1000f).toInt() }
        val bl = s1000.copyOf()
        boxBlur(bl, ws, hs, 3)
        for (y in 1 until hs - 1) for (x in 1 until ws - 1) {
            val i = y * ws + x
            val gx = -sLight[i - ws - 1] - 2f * sLight[i - 1] - sLight[i + ws - 1] + sLight[i - ws + 1] + 2f * sLight[i + 1] + sLight[i + ws + 1]
            val gy = -sLight[i - ws - 1] - 2f * sLight[i - ws] - sLight[i - ws + 1] + sLight[i + ws - 1] + 2f * sLight[i + ws] + sLight[i + ws + 1]
            val mag = sqrt(gx * gx + gy * gy)
            val edge = sstep(0.32f, 0.80f, mag)
            val crease = sstep(0.02f, 0.075f, (bl[i] - s1000[i]) / 1000f)
            inkF[i] = max(edge, crease * 0.9f)
        }
        // 5) susun ke ukuran penuh, tepi garis dipertajam (anti-alias)
        val thLo = 0.50f - p.blur * 0.0030f
        val gr = p.grain / 100f
        val sn = 1f / (1.4f * scale)
        val out = IntArray(w * h)
        for (y in 0 until h) {
            val fy = (y + 0.5f) * hs / h - 0.5f
            for (x in 0 until w) {
                val fx = (x + 0.5f) * ws / w - 0.5f
                val t = bil(toneF, ws, hs, fx, fy)
                val k = sstep(thLo, thLo + 0.30f, bil(inkF, ws, hs, fx, fy))
                val tooth = 1f - gr * 0.05f * vn(x * sn, y * sn, 9)
                out[y * w + x] = (t * (1f - 0.94f * k) * tooth * 255f).toInt().coerceIn(0, 255)
            }
        }
        return out
    }

    /** Blur kotak 3x (mendekati Gaussian), tepi di-clamp. */
    private fun boxBlur(a: IntArray, w: Int, h: Int, r: Int) {
        val tmp = IntArray(max(w, h))
        val k = 2 * r + 1
        repeat(3) {
            for (y in 0 until h) {
                val o = y * w
                var sum = 0
                for (i in -r..r) sum += a[o + i.coerceIn(0, w - 1)]
                for (x in 0 until w) {
                    tmp[x] = sum / k
                    sum += a[o + min(x + r + 1, w - 1)] - a[o + max(x - r, 0)]
                }
                System.arraycopy(tmp, 0, a, o, w)
            }
            for (x in 0 until w) {
                var sum = 0
                for (i in -r..r) sum += a[i.coerceIn(0, h - 1) * w + x]
                for (y in 0 until h) {
                    tmp[y] = sum / k
                    sum += a[min(y + r + 1, h - 1) * w + x] - a[max(y - r, 0) * w + x]
                }
                for (y in 0 until h) a[y * w + x] = tmp[y]
            }
        }
    }
}
